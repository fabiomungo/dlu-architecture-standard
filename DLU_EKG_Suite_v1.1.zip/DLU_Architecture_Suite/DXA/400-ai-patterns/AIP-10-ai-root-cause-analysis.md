# AIP-10 — AI Root Cause Analysis

## Pattern
Grounded, role-aware AI interaction.

## Required UX
Context indicator · answer/action · confidence/uncertainty · evidence/citations · explain-why affordance · correction/escalation path.

## Never
Present generated output as institutional truth without provenance or permission-aware grounding.
